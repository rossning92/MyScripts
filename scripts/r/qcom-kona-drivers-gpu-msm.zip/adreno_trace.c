// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (c) 2013-2014, 2019, The Linux Foundation. All rights reserved.
 */

#include "adreno.h"

/* Instantiate tracepoints */
#define CREATE_TRACE_POINTS
#include "adreno_trace.h"
